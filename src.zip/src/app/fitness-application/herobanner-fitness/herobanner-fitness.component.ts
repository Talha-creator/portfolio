import { Component } from '@angular/core';

@Component({
  selector: 'app-herobanner-fitness',
  templateUrl: './herobanner-fitness.component.html',
  styleUrls: ['./herobanner-fitness.component.scss']
})
export class HerobannerFitnessComponent {

}
