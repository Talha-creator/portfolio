import { Component } from '@angular/core';

@Component({
  selector: 'app-mobileresponsive',
  templateUrl: './mobileresponsive.component.html',
  styleUrls: ['./mobileresponsive.component.scss']
})
export class MobileresponsiveComponent {

}
